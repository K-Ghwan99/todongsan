package com.todongsan.marketservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
